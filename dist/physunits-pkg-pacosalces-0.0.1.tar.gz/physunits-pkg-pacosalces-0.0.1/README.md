# physunits

Simple package with common physical unit definitions. 

## Installation

## Usage

An example usage of this package is:
``from physunits import *``
which updates the globals dict with all ``physunits`` definitions. If only a set of units is desired, manually importing them as:
``from physunits import mm, nm, um``
is sufficient. 

## Contatct and support
